package com.odontologov2.Odontologo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontologoApplicationTests {

	@Test
	void contextLoads() {
	}

}
