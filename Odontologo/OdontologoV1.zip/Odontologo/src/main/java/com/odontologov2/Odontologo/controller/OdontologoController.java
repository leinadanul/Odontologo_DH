package com.odontologov2.Odontologo.controller;

public class OdontologoController {
}
