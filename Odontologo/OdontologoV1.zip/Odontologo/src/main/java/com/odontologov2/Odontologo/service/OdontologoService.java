package com.odontologov2.Odontologo.service;

import com.odontologov2.Odontologo.entity.Odontologo;
import com.odontologov2.Odontologo.repository.OdontologoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OdontologoService {

    private OdontologoRepository odontologoRepository;
    @Autowired
    public OdontologoService(OdontologoRepository odontologoRepository){
        this.odontologoRepository = odontologoRepository;
    }
    public Odontologo guardarOdontologo(Odontologo odontologo){
        return odontologoRepository.save(odontologo);
    }
    public Optional<Odontologo> buscarOdontologo(Long id){
        return odontologoRepository.findById(id);
    }
    public void eliminarOdontologo(Long id){
        odontologoRepository.deleteById(id);
    }
    public void actualizarOdontologo(Odontologo odontologo){
        odontologoRepository.save(odontologo);
    }
    public List<Odontologo> buscarOdontologos(){
        return odontologoRepository.findAll();
    }
    public Optional<Odontologo> buscarOdontologoPorMatricula(String matricula){
        return odontologoRepository.findByInfo(matricula);
    }

}
