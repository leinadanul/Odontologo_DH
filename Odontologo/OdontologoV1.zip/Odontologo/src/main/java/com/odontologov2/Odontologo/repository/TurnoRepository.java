package com.odontologov2.Odontologo.repository;

import com.odontologov2.Odontologo.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository  extends JpaRepository<Turno, Long> {
}
