package com.odontologov2.Odontologo.service;

import com.odontologov2.Odontologo.entity.Paciente;
import com.odontologov2.Odontologo.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service

public class PacienteService {

    private PacienteRepository pacienteRepository;
    @Autowired
    public PacienteService(PacienteRepository pacienteRepository ){
        this.pacienteRepository= pacienteRepository;}
    public Paciente guardarPaciente(Paciente paciente) {
        return pacienteRepository.save(paciente);
    }
    public Optional<Paciente> buscarPaciente(Long id ){
        return  pacienteRepository.findById(id);
    }
    public void eliminarPaciente(Long id){
        pacienteRepository.deleteById(id);
    }
    public void actualizarPaciente(Paciente paciente){
        pacienteRepository.save(paciente);
    }
    public List<Paciente> buscarPacientes(){
        return pacienteRepository.findAll();
    }
    public Optional<Paciente> buscarPacientePorCorreo(String correo){
        return pacienteRepository.findByEmail(correo);
    }
}

