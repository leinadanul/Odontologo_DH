package com.odontologov2.Odontologo.repository;

import com.odontologov2.Odontologo.entity.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PacienteRepository  extends JpaRepository<Paciente,String> {

    Optional<Paciente> findByEmail(String email);

    Optional<Paciente> findById(Long id);

    void deleteById(Long id);
}

